/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mygdx.locomotor;

/**
 *
 * @author 2249229
 */
public class Projectile {
    
    double flatDamage, decayTime;
    
    public void update(){
        
    }
    
}
